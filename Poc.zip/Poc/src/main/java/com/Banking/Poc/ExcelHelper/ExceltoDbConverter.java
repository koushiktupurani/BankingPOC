package com.Banking.Poc.ExcelHelper;

import com.Banking.Poc.Entity.Accounts;
import org.apache.poi.ss.usermodel.Cell;
import org.apache.poi.ss.usermodel.Row;
import org.apache.poi.xssf.usermodel.XSSFSheet;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;
import org.springframework.stereotype.Service;
import org.springframework.web.multipart.MultipartFile;

import java.io.InputStream;
import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;

@Service
public class ExceltoDbConverter {
    public  boolean checkxlFormat(MultipartFile file){
        String type=file.getContentType();
        return type.equals("application/vnd.openxmlformats-officedocument.spreadsheetml.sheet");
    }
    public static List<Accounts> exceltoListConverter(InputStream in){
        List<Accounts> list=new ArrayList<>();
        try{
            XSSFWorkbook workbook = new XSSFWorkbook(in);
            XSSFSheet sheet = workbook.getSheet("data");
            int rowNo =0;
            Iterator<Row> iterator = sheet.iterator();
            while(iterator.hasNext()){
                Row row= iterator.next();
                if(rowNo==0){
                  rowNo++;
                  continue;
                }
                Iterator<Cell> cells = row.iterator();
                Accounts acc=new Accounts();
                int cid=0;
                while(cells.hasNext()){
                    Cell cell=cells.next();
                    switch(cid){
                        case 0:
                            acc.setName(cell.getStringCellValue());
                            break;
                        case 1:
                            acc.setDob(cell.getLocalDateTimeCellValue().toLocalDate());
                            break;
                        case 2:
                            acc.setMobile(cell.getStringCellValue());
                            break;
                        case 3:
                            acc.setAccountType(cell.getStringCellValue());
                            break;
                        case 4:
                            acc.setPan(cell.getStringCellValue());
                            break;
                        default:
                            break;
                    }
                    cid++;
                }
                list.add(acc);

            }

        }catch(Exception e){
            e.printStackTrace();
            throw new RuntimeException("Error while uploading to Data Base");
        }
        return list;

    }
}
