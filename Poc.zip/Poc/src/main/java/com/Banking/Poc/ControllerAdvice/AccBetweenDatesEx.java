package com.Banking.Poc.ControllerAdvice;

public class AccBetweenDatesEx extends RuntimeException {
    public AccBetweenDatesEx(String m) {
        super(m);
    }
}
