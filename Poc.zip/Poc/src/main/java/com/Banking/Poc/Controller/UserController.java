package com.Banking.Poc.Controller;

import com.Banking.Poc.ControllerAdvice.DbEmptyEx;
import com.Banking.Poc.ControllerAdvice.EmptyReqEx;
import com.Banking.Poc.ExcelHelper.DbtoExcelConverter;
import com.Banking.Poc.ExcelHelper.ExceltoDbConverter;
import com.Banking.Poc.Service.UserService;
import jakarta.servlet.http.HttpServletResponse;
import jakarta.validation.Valid;
import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.format.annotation.DateTimeFormat;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;
import com.Banking.Poc.Entity.Accounts;
import org.springframework.web.multipart.MultipartFile;

import java.io.IOException;
import java.time.LocalDate;
import java.util.List;
import java.util.Map;

@RestController
@RequestMapping("Banking")
public class UserController {
    private static final Logger logger= LogManager.getLogger(UserController.class);
    @Autowired
    UserService userservice;
    @Autowired
    DbtoExcelConverter dbtoxl;

    @Autowired
    ExceltoDbConverter xltodb;

    @GetMapping("account/{name}")
    public ResponseEntity<Accounts> getaAccountbyName(@PathVariable String name){
        logger.info("Trying to fetch the account details");
        return new ResponseEntity<Accounts>(userservice.getAnAccount(name), HttpStatus.OK);

    }

    @GetMapping("accounts")
    public ResponseEntity<List<Accounts>> getallAccounts(){
        logger.info("Trying to fetch all the accounts in the bank");
        return new ResponseEntity<List<Accounts>>(userservice.getAllAccounts(),HttpStatus.OK);
    }

    @PostMapping("create/account")
    public ResponseEntity<String> registerAnAccount(@RequestBody @Valid Accounts account){
        logger.info("Trying to create an account");
        if(!userservice.validateAge(account.getDob())){
            return ResponseEntity.status(HttpStatus.BAD_REQUEST).body("AGE MUST BE GREATER THAN 18 YEARS OR LESS THAN 60 YEARS");
        }
        if (userservice.validatePan(account.getPan())) {
            return ResponseEntity.status(HttpStatus.BAD_REQUEST).body("PAN number already exists!!");
        }

        userservice.registerAnAccount(account);
        logger.info("New Account has been Created!");
        return ResponseEntity.status(HttpStatus.CREATED).body("NEW ACCOUNT HAS BEEN CREATED!");
    }

    @GetMapping("/accounts/between")

    public ResponseEntity<List<Accounts>> accountsBetweenDates(@RequestParam("startDate") @DateTimeFormat(pattern="yyyy-MM-dd")LocalDate startDate,
                                                                   @RequestParam("endDate")  @DateTimeFormat(pattern="yyyy-MM-dd") LocalDate endDate){
        List<Accounts> acc=userservice.findAccountsBetween(startDate, endDate);
        logger.info("Accounts created between start and end dates are:"+acc);
        return new ResponseEntity<List<Accounts>>(acc,HttpStatus.OK);

    }

    @DeleteMapping("delete/{name}")
    public String deleteAnAccounts(@PathVariable String name){
        return userservice.deleteAnAccount(name);
    }

    @GetMapping("/download/excel")
    public void generatedExcelreport(HttpServletResponse response) throws IOException{
        response.setContentType("application/octet-stream");
        String headerKey="Content-Disposition";
        String headerValue="attachment;filename=Accounts.xls";
        response.setHeader(headerKey,headerValue);
        dbtoxl.generateExcel(response);
    }

    @PostMapping("/upload/excel")
    public ResponseEntity<?> uploadanExcel(@RequestParam("file")MultipartFile file) throws IOException {
        if(xltodb.checkxlFormat(file)){
            this.userservice.save(file);
            return ResponseEntity.ok(Map.of("message","File is Uploaded and data is saved to Data base"));
        }
        return ResponseEntity.status(HttpStatus.BAD_REQUEST).body("Please upload Excel file only");
    }


}
